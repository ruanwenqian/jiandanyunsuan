package Calcular;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

	public class Welcome extends JFrame implements ActionListener{
		private static MainFrame dl;
		
		private static JButton b1,b2;
			static JFrame j1=new JFrame();
			public Welcome(){
			dl=new MainFrame();	
			JLabel l1=new JLabel("��ӭ������������ϵͳ");
			l1.setBounds(70, 40, 150, 40);
			b1=new JButton("����ϵͳ");
			b2=new JButton("�˳�");
			b1.setBounds(30, 120, 100, 20);
			b2.setBounds(150, 120, 100, 20);
			j1.setLayout(null);
			b1.addActionListener(this);
			b2.addActionListener(this);
			j1.add(l1);
			j1.add(b1);
			j1.add(b2);
			j1.setTitle("��ӭ����");
			j1.setSize(300, 200);
			j1.setLocationRelativeTo(null);
			j1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			j1.setVisible(true);
 
		}
			
			public static void main(String[] args)
			{
				Welcome h=new Welcome();
			}
			
			public void actionPerformed(ActionEvent e)
			{
				if(e.getSource()==b1)
				{
					j1.dispose();
				    dl.setVisible(true);
				}
			
				//�����ϵͳ���˵��µġ��˳����˵���
				if(e.getSource()==b2)
				{
					System.exit(0);
				}
			
			}
			
	}
			
			
		
